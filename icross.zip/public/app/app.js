var app = angular.module('employeeRecords', ['chart.js', 'ngDragDrop'])
    .constant('API_URL', 'http://localhost:8000/api/v1/');